 <?php
 include "conexao.php";
 
	//abra a conexao com o banco de dados

	
	//crie a consulta para excluir cliente do banco de dados

		
	//execute a consulta para excluir	

	
	//verifique se a exclusao foi realizada e emita mensagem de sucesso ou falha

	
	
	//feche a conexao com o banco de dados

  
 ?>
 
	
	
	
	
	
	
	
	
	