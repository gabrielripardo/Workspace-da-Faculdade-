package com.androidexample.broadcastreceiver;

import android.os.Bundle;
import android.app.Activity;


public class BroadcastNewSms extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.androidexample_broadcast_newsms);
	}
}
