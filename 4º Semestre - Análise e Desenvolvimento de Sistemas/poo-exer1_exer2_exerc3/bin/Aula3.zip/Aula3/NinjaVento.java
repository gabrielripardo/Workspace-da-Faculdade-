package pedrapapeltesoura;

public class NinjaVento {

}
