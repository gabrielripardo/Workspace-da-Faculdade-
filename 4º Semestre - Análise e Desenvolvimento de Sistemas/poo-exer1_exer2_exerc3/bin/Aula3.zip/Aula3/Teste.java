package Aula3;

public class Teste {
	/*void imprimirRank(){
		// Imprimir o rank dos vencedores
		System.out.print(">>> Vecendores <<<<");
		System.out.print("1º" + nome);
		System.out.print("2º" + nome);
		System.out.print("3º" + nome);
	}
	*/
	public static void main(String[] args){
		Luta mma = new Luta();
		NinjaTerra ninjaTerra = new NinjaTerra("Terra");
		NinjaFogo ninjaFogo = new NinjaFogo("Fogo");
		NinjaAgua ninjaAgua = new NinjaAgua("Agua");	
		
		//mma.iniciarLuta(ninjaTerra, ninjaFogo); // Fighter
		mma.iniciarLuta(ninjaAgua, ninjaFogo); // Fighter
		mma.iniciarLuta(ninjaTerra, ninjaFogo);
		
		int ptsTerra = ninjaTerra.getPontos();
		int ptsAgua = ninjaAgua.getPontos();
		int ptsFogo = ninjaAgua.getPontos();
		
		String first = "8teste";
		String second = null;
		String third = null;
		
		//System.out.print(first.charAt(0));
		//int njAgua = Integer.parseInt(first, first.charAt(0));
		
		//System.out.print("String to int -> " + njAgua);
		
		
		System.out.println("1º - " + ninjaTerra.getNome() + " Pontos: " + ninjaTerra.getPontos());
		System.out.println("2º - " + ninjaFogo.getNome() + " Pontos: " + ninjaFogo.getPontos());
		System.out.println("3º - " + ninjaAgua.getNome() + " Pontos: " + ninjaAgua.getPontos());
		
		if(ptsTerra > ptsAgua && ptsAgua > ptsFogo){
			first = ninjaTerra.getNome();
			second = ninjaAgua.getNome();
			third = ninjaFogo.getNome();
		}else if(ptsAgua > ptsTerra && ptsTerra > ptsFogo ){
			first = ninjaAgua.getNome();
			second = ninjaTerra.getNome();
			third = ninjaFogo.getNome();
		}
		
		
	}
}
