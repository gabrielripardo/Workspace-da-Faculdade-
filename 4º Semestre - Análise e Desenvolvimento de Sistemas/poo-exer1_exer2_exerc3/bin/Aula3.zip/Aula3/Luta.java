package Aula3;
 // Cada luta: Terá 3 Rounds de lutas eninja2re os dois ninjas, o ninja que ganhar	
// mais rounds	vence a luta e recebe 3 poninja2os. Se impatar cada ninja ganha um poninja2o
public class Luta {
	void iniciarLuta(Ninja ninja1, Ninja ninja2) {
		byte winnerroundcomp1 = 0;
		byte winnerroundcomp2 = 0;
		
		for(int round=1; round<=3; round++){// Sempre que roda o valor do ataque muda
			 
			byte comp1 = ninja1.atacar(); // Atualiza o método e busca um novo ataque
			byte comp2 = ninja2.atacar();
			
			System.out.println("Round: " + round + " - Ninja1: " + comp1);
			System.out.println("Round: " + round+ " - Ninja2: " + comp2);
			
			// >>> Ataques vs Ataques << 
			if(comp1 == 1 && comp2 == 4){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 4 && comp2 == 1){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 2 && comp2 == 5){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 5 && comp2 == 2 ){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 3 && comp2 == 4){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 4 && comp2 == 3){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 5 && comp2 == 3){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 3 && comp2 == 5){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 4 && comp2 == 5){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 5 && comp2 == 4){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 2 && comp2 == 1){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 1 && comp2 == 2){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 1 && comp2 == 3){
				winnerroundcomp1++;
				System.out.print("comp2++");
			}if(comp1 == 3 && comp2 == 1){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 3 && comp2 == 2){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 2 && comp2 == 3){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 5 && comp2 == 1){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 1 && comp2 == 5){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 4 && comp2 == 2){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 2 && comp2 == 4){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			///////////////////////////////
		}
		// Ganhador da luta
		if(winnerroundcomp1 > winnerroundcomp2){
			ninja1.addPontosVitoria();
		}else if(winnerroundcomp1 == winnerroundcomp2){
			ninja1.addPontosEmpate(); ninja2.addPontosEmpate();
		}else{
			ninja2.addPontosVitoria();
		}
	}
}

/*
 * if(comp1 == 1 && comp2 == 4){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 4 && comp2 == 1){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 2 && comp2 == 5){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 5 && comp2 == 2 ){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 3 && comp2 == 4){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 4 && comp2 == 3){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 5 && comp2 == 3){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 3 && comp2 == 5){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 4 && comp2 == 5){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 5 && comp2 == 4){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 2 && comp2 == 1){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 1 && comp2 == 2){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 1 && comp2 == 3){
				winnerroundcomp1++;
				System.out.print("comp2++");
			}if(comp1 == 3 && comp2 == 1){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 3 && comp2 == 2){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 2 && comp2 == 3){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
			if(comp1 == 5 && comp2 == 1){
				winnerroundcomp1++;
				System.out.print("comp1++");
			}if(comp1 == 1 && comp2 == 5){
				winnerroundcomp2++;
				System.out.print("comp2++");
			}//
 */
