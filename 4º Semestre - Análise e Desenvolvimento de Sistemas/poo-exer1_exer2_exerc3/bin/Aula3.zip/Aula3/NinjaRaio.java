package pedrapapeltesoura;

public class NinjaRaio {

}
